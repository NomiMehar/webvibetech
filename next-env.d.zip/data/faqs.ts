export type FaqItem = {
  title: string;
  desc: string;
};

export const faqsByKey: Record<string, FaqItem[]> = {
  home: [
    {
      title: "What services does Webvibe Tech provide?",
      desc: "Webvibe Tech delivers end-to-end digital engineering across seven practice areas: Website Development, Mobile App Development, Custom Software Development, AI & Automation, UI/UX Design, CRM Development, and SEO. Each practice is staffed by senior specialists who remain hands-on from kickoff to launch.",
    },
    {
      title: "How is Webvibe Tech different from other software agencies?",
      desc: "We run a studio model, not an account management model. Lead engineers and designers stay on your project — there's no bait-and-switch between the team you meet and the team that builds. Every engagement includes explicit QA gates, observability, and documentation, so the handover is a non-event rather than a scramble.",
    },
    {
      title: "Which industries does Webvibe Tech have experience in?",
      desc: "We've shipped production systems across Fintech, Healthcare, E-commerce, Logistics, SaaS, Real Estate, Education, Media, and early-stage startups. We treat domain knowledge as a prerequisite — not something we learn on your budget.",
    },
    {
      title: "How long does a typical project take from kickoff to launch?",
      desc: "Kickoff to roadmap typically takes 10 business days. From there, timelines depend on scope: a focused MVP can ship in 6–10 weeks; a full SaaS platform or AI integration typically runs 12–20 weeks. We provide a scoped estimate with milestones before any work begins — no open-ended retainers without defined deliverables.",
    },
    {
      title: "Does Webvibe Tech offer ongoing support and maintenance after launch?",
      desc: "Yes. We offer structured post-launch support that includes monitoring, incident response, performance tuning, and iterative feature development. Support arrangements are defined upfront — we don't offer vague 'maintenance packages.' You'll know exactly what's covered and what the SLA is.",
    },
    {
      title: "Can Webvibe Tech work with our existing codebase or vendor?",
      desc: "Absolutely. We regularly join projects mid-stream — inheriting codebases, conducting technical audits, and integrating with existing vendors or platforms. Our first step is always a technical archaeology session to map what exists, what the constraints are, and what the safe path forward looks like.",
    },
    {
      title: "How does the AI & Automation practice work in practice?",
      desc: "We begin with use-case validation — not every workflow benefits from AI. Once a use case is confirmed, we design the system with evals, tracing, and human-in-the-loop policies built in from the start. We also set explicit cost and latency budgets tracked in CI, so AI features don't degrade silently in production.",
    },
    {
      title: "What does the project kick-off process look like?",
      desc: "We start with a structured discovery session covering stakeholder goals, technical constraints, and measurable success criteria. This produces a decision log — a concise document that defines what must be true in 90 days, what's out of scope, and how we'll measure progress. From there, design and development run in overlapping phases rather than sequential hand-offs.",
    },
  ],
  services: [
    {
      title: "What services does Webvibe provide for businesses?",
      desc: "Webvibe offers a comprehensive range of services, including custom software development, web development, mobile app development, cloud hosting, AI solutions, UI/UX design, and digital marketing.",
    },
    {
      title: "How can Webvibe help with business growth and digital transformation?",
      desc: "Webvibe supports businesses by offering scalable technology solutions that streamline operations, automate processes, and improve customer engagement to drive long-term growth.",
    },
    {
      title: "Which industries does Webvibe serve with its technology solutions?",
      desc: "We serve industries such as e-commerce, healthcare, financial services, education, and logistics by delivering industry-specific solutions tailored to their needs.",
    },
    {
      title: "What makes Webvibe different from other technology providers?",
      desc: "Webvibe stands out due to its use of cutting-edge technologies, custom-tailored solutions, and a proven track record of delivering scalable, high-quality software on time.",
    },
    {
      title: "Does Webvibe offer ongoing support and maintenance for projects?",
      desc: "Yes, we provide long-term maintenance and support for all projects, including regular updates, performance optimizations, and software scalability improvements to meet evolving business needs.",
    },
  ],
  website_development: [
    { title: "How long does a website development project take?", desc: "Most website development projects take between 4 to 8 weeks, depending on complexity, features, and integrations. Larger or custom platforms may require additional time." },
    { title: "Do you build SEO into your website development?", desc: "Yes. SEO is integrated into every website we build, including clean site architecture, mobile optimisation, performance best practices, and SEO-friendly page structures." },
    { title: "Can you redesign or rebuild an existing website?", desc: "Absolutely. We regularly rebuild or redesign existing websites to improve performance, usability, and conversions while preserving valuable SEO equity where possible." },
    { title: "Which platforms do you use for website development?", desc: "We work with platforms such as WordPress, Shopify, Webflow, and fully custom solutions depending on your requirements, scalability needs, and long-term goals." },
    { title: "Do you provide ongoing website support after launch?", desc: "Yes. We offer website maintenance and support services to ensure your site remains secure, updated, and optimised as your business grows." },
  ],
  ecommerce_website_development: [
    { title: "How long does an e-commerce website project take?", desc: "Most e-commerce projects take between 6 and 10 weeks, depending on platform, catalogue size, and integrations." },
    { title: "Which e-commerce platform should I use?", desc: "That depends on your business model, growth plans, and operational complexity. We help you choose the right platform." },
    { title: "Can you rebuild or improve an existing e-commerce store?", desc: "Yes. We regularly rebuild or optimise existing stores to improve performance, usability, and conversions." },
    { title: "Do you provide ongoing e-commerce support?", desc: "Yes. We offer ongoing maintenance, optimisation, and feature development." },
  ],
  wordpress_development: [
    { title: "How long does a WordPress website project take?", desc: "Most WordPress website projects take between 4-8 weeks, depending on complexity, third-party integrations, and content readiness. Larger or highly customized builds may require additional time. We define clear milestones and timelines during the discovery phase." },
    { title: "Do you use pre-built themes or custom WordPress themes?", desc: "We primarily develop custom WordPress themes tailored to your business needs. Custom themes provide better performance, stronger security, cleaner code, and long-term flexibility compared to pre-built themes." },
    { title: "Is WordPress suitable for large or enterprise websites?", desc: "Yes. When properly architected, WordPress can support enterprise-level traffic, complex content structures, and advanced integrations. We design scalable solutions using best practices to ensure stability, speed, and security at scale." },
    { title: "Do you provide ongoing WordPress maintenance?", desc: "Yes. We offer ongoing WordPress maintenance services, including security monitoring, regular updates, backups, performance optimization, and technical support to keep your website running smoothly." },
  ],
  shopify_development: [
    { title: "How long does a Shopify development project take?", desc: "Most Shopify projects take between 4 and 8 weeks, depending on catalogue size, customisation, and integrations." },
    { title: "Do you build custom Shopify themes or use templates?", desc: "We primarily build custom or heavily customised themes to ensure performance, flexibility, and brand consistency." },
    { title: "Can you migrate my store to Shopify?", desc: "Yes. We handle full Shopify migrations, including products, customers, orders, and SEO-safe URL mapping." },
    { title: "Do you offer ongoing Shopify support?", desc: "Yes. We provide ongoing maintenance, performance optimisation, updates, and feature enhancements." },
  ],
  landing_page_development: [
    { title: "How long does it take to build a landing page?", desc: "Most landing pages are completed within 1 to 2 weeks, depending on complexity and feedback cycles." },
    { title: "Do you design landing pages for paid ads?", desc: "Yes. We build landing pages specifically aligned to Google Ads, Meta Ads, and LinkedIn campaigns." },
    { title: "Can you optimize an existing landing page?", desc: "Absolutely. We regularly optimize existing landing pages to improve speed, usability, and conversion rates." },
    { title: "Do you provide A/B testing support?", desc: "Yes. We support ongoing testing and optimisation based on performance data." },
  ],
  website_maintenance: [
    { title: "Why do I need ongoing website maintenance?", desc: "Regular maintenance prevents security issues, performance degradation, and compatibility problems before they affect users or rankings." },
    { title: "How often do you perform updates?", desc: "Updates are performed on a scheduled basis, with priority fixes applied immediately when needed." },
    { title: "Can you fix an already compromised website?", desc: "Yes. We handle malware removal, recovery, and security hardening as part of our support services." },
    { title: "Do you provide emergency support?", desc: "Yes. Our maintenance plans include rapid-response support for critical issues." },
    { title: "Can you maintain websites built by other agencies?", desc: "Absolutely. We regularly take over maintenance for existing websites built on various platforms." },
  ],
  custom_website_development: [
    { title: "How long does a custom website project take?", desc: "Most custom website projects take between 6 and 10 weeks, depending on complexity and integrations." },
    { title: "Will we own the website code?", desc: "Yes. You retain full ownership of the codebase and intellectual property." },
    { title: "Can our team manage content after launch?", desc: "Absolutely. We build intuitive CMS solutions and provide training where required." },
    { title: "Do you build SEO-ready custom websites?", desc: "Yes. Technical SEO is built into every custom project from the start." },
    { title: "Do you provide ongoing support?", desc: "Yes. We offer ongoing maintenance and development support post-launch." },
  ],
  webflow_development: [
    { title: "How long does a Webflow website take to build?", desc: "Most Webflow projects take between 3 and 6 weeks, depending on complexity and CMS requirements." },
    { title: "Can you migrate my existing site to Webflow?", desc: "Yes. We handle full Webflow migrations while preserving SEO and content structure." },
    { title: "Is Webflow good for SEO?", desc: "Yes. When built correctly, Webflow supports clean markup, fast load times, and strong technical SEO foundations." },
    { title: "Do you offer ongoing Webflow support?", desc: "Yes. We provide maintenance, optimisation, and ongoing enhancements." },
  ],
  mobile_app_development: [
    { title: "How long does a mobile app development project take?", desc: "Most mobile app projects take between 8 and 16 weeks, depending on features, integrations, and platform requirements." },
    { title: "Do you build native or cross-platform apps?", desc: "We build both. The choice depends on performance needs, timelines, and long-term scalability." },
    { title: "Can you improve or rebuild an existing mobile app?", desc: "Yes. We regularly rebuild and optimise existing apps to improve performance, usability, and stability." },
    { title: "Do you handle App Store and Play Store submissions?", desc: "Yes. We support app preparation, compliance, and submission for both platforms." },
  ],
  ios_app_development: [
    { title: "How long does an iOS app development project take?", desc: "Most iOS app projects take between 8 and 16 weeks, depending on features, integrations, and complexity." },
    { title: "Do you build fully native iOS apps?", desc: "Yes. We specialise in native iOS development using Swift and modern Apple frameworks." },
    { title: "Can you rebuild or improve an existing iOS app?", desc: "Absolutely. We regularly refactor, rebuild, and optimise existing apps to improve performance, usability, and stability." },
    { title: "Do you handle App Store submission and compliance?", desc: "Yes. We support app preparation, App Store compliance checks, and submission." },
    { title: "Do you provide ongoing iOS app support after launch?", desc: "Yes. We offer maintenance, monitoring, updates, and feature enhancements as part of our ongoing support services." },
  ],
  android_app_development: [
    { title: "How long does an Android app development project take?", desc: "Most Android app projects take between 8 and 16 weeks, depending on complexity, features, and integrations." },
    { title: "Do you build fully native Android apps?", desc: "Yes. We specialise in native Android development using Kotlin and modern Android frameworks." },
    { title: "Can you rebuild or optimise an existing Android app?", desc: "Yes. We regularly refactor, rebuild, and optimise existing Android apps to improve performance and usability." },
    { title: "Do you handle Google Play Store submission?", desc: "Yes. We support app preparation, compliance checks, and Play Store submission." },
    { title: "Do you provide ongoing Android app support after launch?", desc: "Yes. We offer maintenance, monitoring, updates, and feature enhancements." },
  ],
  flutter_app_development: [
    { title: "Is Flutter suitable for large-scale applications?", desc: "Yes. When architected properly, Flutter can support complex, high-traffic applications across platforms." },
    { title: "How long does a Flutter app development project take?", desc: "Most Flutter projects take between 8 and 14 weeks, depending on features and integrations." },
    { title: "Will my Flutter app feel native on iOS and Android?", desc: "Yes. Flutter enables native-like performance and smooth UI when implemented correctly." },
    { title: "Can you migrate an existing app to Flutter?", desc: "Yes. We support Flutter migrations and rebuilds where cross-platform efficiency makes sense." },
    { title: "Do you provide ongoing Flutter app support?", desc: "Yes. We offer maintenance, optimisation, and feature development post-launch." },
  ],
  app_ui_ux: [
    { title: "Do you design for both iOS and Android?", desc: "Yes. Our designs align with both iOS Human Interface Guidelines and Android Material Design principles." },
    { title: "Can you redesign an existing app UI UX?", desc: "Absolutely. We regularly redesign apps to improve usability, engagement, and conversion." },
    { title: "Do you provide developer-ready design files?", desc: "Yes. All designs are delivered with clear specifications and assets ready for development." },
    { title: "Can you work with our existing development team?", desc: "Yes. We collaborate closely with in-house or external development teams." },
    { title: "Do you offer UX testing and validation?", desc: "Yes. Prototyping and usability validation are part of our process." },
  ],
  app_maintenance: [
    { title: "What is included in your app maintenance services?", desc: "Monitoring, bug fixes, performance optimisation, security updates, backups, and OS compatibility updates." },
    { title: "Why do I need ongoing app maintenance?", desc: "Regular maintenance prevents crashes, security issues, and performance decline that negatively impact users and revenue." },
    { title: "How quickly do you respond to critical issues?", desc: "We offer rapid-response support with defined SLAs for critical incidents." },
    { title: "Can you take over maintenance for an existing app?", desc: "Yes. We regularly take over maintenance for apps built by other teams after an initial audit." },
    { title: "Do you support both iOS and Android apps?", desc: "Yes. We maintain native and cross-platform applications across both platforms." },
  ],
  software_development: [
    { title: "How long does a custom software development project take?", desc: "Project timelines vary based on complexity and scope. Custom software development typically takes 8-16 weeks, with larger enterprise solutions requiring more time." },
    { title: "What technologies do you use for custom software development?", desc: "We work with a wide range of technologies including React, Node.js, Python, Java, and Ruby on Rails to build scalable, secure, and high-performance applications." },
    { title: "Can you help me migrate my existing software to a new platform?", desc: "Yes. We specialize in migrating legacy systems to modern platforms with minimal disruption and data loss. We ensure data integrity and continuity during the migration process." },
    { title: "Will I be able to update and maintain the software myself?", desc: "Yes. We ensure the software is easy to maintain with a user-friendly backend and provide training to your team to manage the platform independently." },
    { title: "Do you provide ongoing support after the software is launched?", desc: "Yes. We offer continuous support, including bug fixes, updates, and feature expansions, to ensure your software remains secure and relevant." },
  ],
  custom_software_development: [
    { title: "What is custom software development?", desc: "Custom software development is the process of designing, creating, deploying, and maintaining software that is tailored to meet the specific needs of a business or user." },
    { title: "How long does it take to build a custom application?", desc: "The timeline depends on the project's complexity. Simple applications might take a few months, while enterprise solutions could take a year or more. We provide a detailed project timeline during the consultation phase." },
    { title: "Is custom software more expensive than off-the-shelf solutions?", desc: "While the upfront cost of custom software is higher, it provides a greater return on investment over time. Custom software eliminates licensing fees and can scale with your business, reducing the need for costly replacements." },
    { title: "Can you work with my existing software and systems?", desc: "Yes. We specialize in integrating custom software with your current systems, creating a seamless and unified IT environment." },
    { title: "What kind of support do you offer after the software is launched?", desc: "We offer comprehensive post-launch support, including bug fixes, performance monitoring, and feature updates to ensure your software remains secure and effective." },
  ],
  web_app_development: [
    { title: "How long does a web app development project take?", desc: "Project timelines vary based on complexity and scope. Most web app projects take between 8-16 weeks, with larger enterprise solutions requiring more time." },
    { title: "What technologies do you use for web app development?", desc: "We work with modern technologies including React, Next.js, Node.js, Python, and other frameworks to build scalable, secure, and high-performance web applications." },
    { title: "Can you integrate my web app with third-party services?", desc: "Yes. We specialize in API development and integration, allowing seamless communication between your web app and external services, platforms, and systems." },
    { title: "Are your web apps mobile-optimized?", desc: "Yes. All our web applications are built with a mobile-first approach, ensuring optimal performance and user experience across all devices and screen sizes." },
    { title: "Do you provide ongoing support after launch?", desc: "Yes. We offer continuous support including bug fixes, updates, performance optimization, and feature expansions to ensure your web app remains secure and relevant." },
  ],
  saas_development: [
    { title: "How long does SaaS application development take?", desc: "Development time varies depending on complexity. A simple MVP takes around 3-6 months, while a fully-featured SaaS product can take longer. We provide a detailed timeline after our initial consultation." },
    { title: "What is the cost of building a SaaS application?", desc: "Costs vary based on the scope and features required. After an initial consultation, we provide an estimate tailored to your project needs." },
    { title: "Can you help me scale my existing SaaS product?", desc: "Yes. We offer SaaS modernization services and can scale your existing platform to improve performance and accommodate a growing user base." },
    { title: "What technologies do you use?", desc: "We use a variety of modern technologies including React, Node.js, AWS, and Google Cloud, choosing the best stack based on your project needs." },
    { title: "Do you provide ongoing support after launch?", desc: "Yes. We offer SaaS maintenance, security updates, and performance optimization as part of our ongoing support." },
  ],
  mvp_development: [
    { title: "What is the average timeline for building an MVP?", desc: "Most MVPs we build take between six to twelve weeks. The exact time depends on the complexity of the features. We focus on the core value proposition to ensure we launch as fast as possible without compromising stability." },
    { title: "How much does MVP development cost?", desc: "Costs vary based on the scope but we pride ourselves on offering minimum viable product development services that fit startup budgets. We provide transparent pricing and help you prioritize features to keep costs manageable." },
    { title: "Do I own the code after the project is finished?", desc: "Yes, absolutely. You own 100% of the code and intellectual property. We are here to build your asset. Once the project is complete and paid for, everything belongs to you." },
    { title: "Can you help with updates after launch?", desc: "Yes, we love long-term partnerships. Many clients retain us for ongoing maintenance and feature additions. We can continue to support your growth as your technical team." },
    { title: "Do I need technical knowledge to work with you?", desc: "No, you do not. We handle all the technical heavy lifting. We communicate in plain English and keep you updated on progress so you can focus on marketing and business development." },
  ],
  api_development: [
    { title: "What is API development?", desc: "API development is the process of building Application Programming Interfaces (APIs), which act as a set of rules and tools for building software applications. APIs allow different software systems to communicate and share data in a structured and secure way." },
    { title: "Why are API integration services important?", desc: "API integration is crucial for connecting various systems and platforms, enabling automation, data synchronization, and enhanced functionality without having to build new features from scratch." },
    { title: "What is the difference between REST and GraphQL APIs?", desc: "REST and GraphQL are two popular API styles. REST is a widely used standard that creates scalable and reliable web services, while GraphQL allows clients to request only the data they need, making it more efficient for complex applications." },
    { title: "How do you ensure the security of the APIs you build?", desc: "We implement industry-standard security practices, including authentication (OAuth 2.0), data encryption, rate limiting, and input validation, to ensure your data and API interactions remain secure." },
    { title: "What does the API testing and maintenance process involve?", desc: "Our API testing services include functional testing, performance testing, and security audits. Post-launch, we offer ongoing maintenance to handle updates, monitor performance, and ensure compatibility with evolving systems." },
  ],
  ai_automation: [
    { title: "What types of businesses benefit most from AI & automation?", desc: "Organisations with repeatable processes, operational complexity, or growing data volumes see the strongest ROI." },
    { title: "Do you work with existing tools and systems?", desc: "Yes. Most solutions integrate directly with CRMs, ERPs, internal platforms, and third-party tools." },
    { title: "Is AI automation secure for enterprise use?", desc: "Yes, when designed properly. We implement access controls, data governance, and secure deployment models." },
    { title: "Can we start with one AI use case?", desc: "Absolutely. Many clients begin with a single automation or agent and expand over time." },
    { title: "Do you provide ongoing support?", desc: "Yes. We offer monitoring, optimisation, and continuous improvement for all AI systems we build." },
  ],
  ai_agents: [
    { title: "What are AI Agents?", desc: "AI Agents are software components powered by AI that execute specific tasks, interact with systems, and assist teams within defined scopes." },
    { title: "Are AI Agents the same as chatbots?", desc: "No. Chatbots focus on conversation. AI Agents perform actions, interact with systems, and execute tasks." },
    { title: "Can AI Agents integrate with our existing tools?", desc: "Yes. We integrate agents with CRMs, ERPs, databases, APIs, and internal software." },
    { title: "Do AI Agents make decisions independently?", desc: "No. They operate within predefined rules and escalate when human input is required." },
    { title: "Is this secure for enterprise use?", desc: "Yes. We implement permissions, logging, and access controls for safe deployment." },
  ],
  agentic_ai: [
    { title: "What is Agentic AI?", desc: "Agentic AI refers to AI systems that can autonomously plan, decide, and execute actions toward goals, rather than only responding to inputs." },
    { title: "How is this different from automation?", desc: "Traditional automation follows predefined rules. Agentic AI reasons, adapts, and handles variability without breaking." },
    { title: "Is Agentic AI safe for enterprise use?", desc: "Yes, when engineered correctly. We implement permissions, logging, constraints, and escalation mechanisms to ensure control and compliance." },
    { title: "Can Agentic AI integrate with our existing systems?", desc: "Absolutely. Our agents interact directly with APIs, databases, SaaS tools, and internal software." },
    { title: "Do humans stay in control?", desc: "Yes. We design human-in-the-loop models where agents operate autonomously within defined boundaries and escalate when required." },
  ],
  ai_chatbots: [
    { title: "What types of chatbots do you build?", desc: "Customer support bots, sales and lead qualification bots, transactional bots, and internal AI assistants." },
    { title: "Do your chatbots use NLP and machine learning?", desc: "Yes. We implement natural language understanding to interpret intent, context, and variations in user input." },
    { title: "Can the chatbot integrate with our CRM or support tools?", desc: "Yes. We integrate with CRMs, ticketing systems, databases, and custom APIs." },
    { title: "How long does chatbot development take?", desc: "Simple use cases can launch in 3-5 weeks. More complex implementations typically take 8-12 weeks." },
    { title: "Do you provide post-launch support?", desc: "Yes. We provide monitoring, retraining, optimisation, and feature expansion." },
  ],
  llm_development: [
    { title: "What is the difference between custom LLM development and fine-tuning?", desc: "Custom development builds a model specifically for your data and use cases, while fine-tuning adapts an existing model for better accuracy and relevance." },
    { title: "Can you deploy LLMs privately?", desc: "Yes. We support private cloud and on-premise LLM deployments to maintain data control and compliance." },
    { title: "How long does LLM development take?", desc: "Most projects take between 6 and 16 weeks, depending on data readiness, model complexity, and integrations." },
    { title: "Do you integrate LLMs with existing systems?", desc: "Yes. We integrate LLMs with CRMs, ERPs, internal tools, and custom platforms via secure APIs." },
    { title: "Do you provide ongoing optimisation and support?", desc: "Yes. We offer continuous monitoring, retraining, and optimisation to maintain accuracy and performance." },
  ],
  automation_workflows: [
    { title: "What is automation and workflow engineering?", desc: "It is the design and implementation of systems that automate repetitive processes, integrate tools, and orchestrate how work flows across a business." },
    { title: "Can you automate complex or legacy systems?", desc: "Yes. We regularly integrate modern automation platforms with legacy systems using APIs, RPA, or custom connectors." },
    { title: "How long does an automation project take?", desc: "Simple workflows may take weeks. More complex, cross-system automation typically runs over several phases. Timelines are defined during discovery." },
    { title: "Is automation secure?", desc: "Security is built into every workflow, including access controls, auditability, and compliance requirements." },
    { title: "What happens after deployment?", desc: "We provide monitoring, optimisation, and ongoing support to ensure automation remains reliable and effective." },
  ],
  generative_ai: [
    { title: "What is Generative AI development?", desc: "Generative AI development involves building systems that can generate text, data, or other outputs using AI models, engineered to operate reliably within real business environments." },
    { title: "Do you use public models like GPT?", desc: "We can use leading models where appropriate, but always within controlled architectures, often combined with private data and Retrieval Augmented Generation to ensure accuracy and security." },
    { title: "Is our data kept private?", desc: "Yes. We design solutions that respect data ownership, security, and compliance. Models can be deployed within your private cloud or infrastructure." },
    { title: "Can Generative AI integrate with our existing systems?", desc: "Absolutely. We specialise in integrating Generative AI into existing software, workflows, CRMs, ERPs, and internal tools." },
    { title: "Is this suitable for enterprise use?", desc: "Yes. Our Generative AI solutions are designed for production, scalability, and governance, not experimentation." },
  ],
  ui_ux_design: [
    { title: "What’s the difference between UI and UX design?", desc: "UX design focuses on structure, flow, and usability. UI design focuses on visual clarity, hierarchy, and consistency. Both work together to create effective digital experiences." },
    { title: "Do you work with existing products or only new ones?", desc: "Both. We redesign existing platforms, audit and improve live products, and design new products from scratch." },
    { title: "Will designs be developer-ready?", desc: "Yes. Our designs are built with implementation in mind, including design systems, components, and clear handoff documentation." },
    { title: "Can you work alongside our internal team?", desc: "Absolutely. We regularly collaborate with in-house product, marketing, and development teams." },
    { title: "Do you offer ongoing design support?", desc: "Yes. Many clients retain us for continuous design improvements as their product evolves." },
  ],
  ux_research: [
    { title: "What's the difference between UX research and UX design?", desc: "UX research uncovers insight. UX design applies it. Research informs design decisions before and during execution." },
    { title: "How long does a UX research project take?", desc: "From one to two weeks for focused testing, to several weeks for deeper research. Scope is adjusted to your needs." },
    { title: "Do you recruit users for testing?", desc: "Yes. We handle recruitment, screening, and coordination where required." },
    { title: "Can UX research work alongside active development?", desc: "Absolutely. We often run research in parallel with development to inform iterations." },
    { title: "Is UX research worth it for early-stage products?", desc: "Yes. Early research reduces wasted development and helps validate direction before heavy investment." },
  ],
  ui_design: [
    { title: "What's the difference between UI and UX design?", desc: "UX focuses on structure, flow, and experience. UI focuses on visual presentation and interaction clarity. Both work together." },
    { title: "Do you redesign existing products?", desc: "Yes. UI redesigns are often driven by audits, usability issues, or product growth." },
    { title: "What tools do you use?", desc: "Primarily Figma, with structured design systems and component libraries." },
    { title: "Can you work with our existing brand guidelines?", desc: "Yes. We can follow existing systems or help refine and scale them." },
    { title: "What do we receive at the end?", desc: "Design files, components, prototypes, and documentation ready for development." },
  ],
  ux_audit: [
    { title: "How long does a UX audit take?", desc: "Typically 2 to 4 weeks depending on product size and scope." },
    { title: "Do you need access to analytics?", desc: "Helpful but not mandatory. We adapt based on available data." },
    { title: "Is a UX audit different from user testing?", desc: "Yes. A UX audit is expert-led. User testing observes real users. Both complement each other." },
    { title: "Can this help SEO?", desc: "Indirectly, yes. Improved UX often reduces bounce rates and increases engagement, which supports SEO performance." },
    { title: "Can you support implementation after the audit?", desc: "Yes. Many clients continue into UI design or optimisation phases." },
  ],
  wireframing_prototyping: [
    { title: "How long does wireframing and prototyping take?", desc: "From 1 to 4 weeks depending on scope and complexity." },
    { title: "Do you work with existing products?", desc: "Yes. We often prototype redesigns, new features, or improvements." },
    { title: "Can prototypes be user tested?", desc: "Absolutely. Prototypes are ideal for early usability testing." },
    { title: "What tools do you use?", desc: "Primarily Figma, with outputs ready for modern dev workflows." },
    { title: "Can this feed directly into development?", desc: "Yes. Our artefacts are structured for smooth engineering handoff." },
  ],
  design_system: [
    { title: "Do we need a design system if we are early-stage?", desc: "Yes. Even lightweight systems prevent future design debt." },
    { title: "Can you build on an existing design system?", desc: "Absolutely. We audit, refine, and extend existing systems." },
    { title: "Does this work with our frontend stack?", desc: "Yes. We align with modern frameworks and workflows." },
    { title: "How long does it take?", desc: "Typically 3-6 weeks depending on scope and complexity." },
    { title: "Is this only for large teams?", desc: "No. Startups benefit just as much from consistency and speed." },
  ],
  product_design: [
    { title: "What is product design?", desc: "Product design is the process of defining how a digital product works, feels, and evolves. It combines UX, UI, and strategic thinking to ensure the product solves real problems and meets business goals." },
    { title: "Do you work with startups and early-stage products?", desc: "Yes. We regularly design MVPs and early-stage products, helping teams validate ideas, reduce risk, and move to market with confidence." },
    { title: "Can you redesign an existing product?", desc: "Absolutely. We audit existing products, identify usability and adoption issues, and redesign with minimal disruption and clear improvement goals." },
    { title: "How long does product design take?", desc: "Timelines depend on scope. MVPs typically take 4-6 weeks. Larger SaaS or enterprise products may take longer. We provide clear timelines after discovery." },
    { title: "Do you work alongside development teams?", desc: "Yes. Our process is built to integrate tightly with engineering, ensuring designs are practical, buildable, and scalable." },
  ],
  crm_development: [
    { title: "Do we need a custom CRM or can you customise an existing one?", desc: "It depends on your complexity and growth plans. We assess both options and recommend the most cost-effective long-term approach." },
    { title: "Can you integrate our CRM with existing tools?", desc: "Yes. We specialise in CRM integrations across marketing, finance, analytics, support, and internal systems." },
    { title: "Will our team actually use the CRM?", desc: "That is the point. We prioritise usability and workflow alignment to ensure adoption, not resistance." },
    { title: "How long does CRM development take?", desc: "Simple customisations can take weeks. Full custom CRM platforms typically take 8-16 weeks depending on scope." },
    { title: "Do you provide ongoing support?", desc: "Yes. We support enhancements, optimisation, and scaling as your business evolves." },
  ],
  crm_implementation: [
    { title: "How long does CRM implementation take?", desc: "Typically 4-10 weeks, depending on data complexity, automation, and integrations." },
    { title: "Can you fix a failed CRM implementation?", desc: "Yes. We regularly audit and repair broken CRM setups without starting over." },
    { title: "Do you handle data migration?", desc: "Yes. Migration, cleanup, validation, and post-migration testing are included." },
    { title: "Will teams receive onboarding support?", desc: "We prioritise usability and provide structured adoption support where needed." },
    { title: "Can the CRM be extended later?", desc: "Yes. We design CRM systems to scale and adapt as your business grows." },
  ],
  erp: [
    { title: "How long does ERP implementation take?", desc: "Typically 3-9 months depending on modules, integrations, and data complexity." },
    { title: "Can you optimise an existing ERP system?", desc: "Yes. We regularly audit and restructure underperforming ERP setups." },
    { title: "Do you handle data migration and reconciliation?", desc: "Yes. Data accuracy and validation are core to our ERP delivery." },
    { title: "Can ERP integrate with CRM and automation tools?", desc: "Absolutely. ERP is most effective when tightly integrated with CRM and automation." },
    { title: "Is ERP suitable for mid sized businesses?", desc: "Yes. ERP is not just for large enterprises when implemented correctly." },
  ],
  crm_customization: [
    { title: "Can you customise an existing CRM without rebuilding it?", desc: "Yes. Most customisation improves existing setups without full reimplementation." },
    { title: "Will customisation affect CRM upgrades?", desc: "No. We design changes that remain compatible with platform updates." },
    { title: "Can you fix poor CRM adoption?", desc: "Yes. Adoption issues are usually caused by workflow misalignment, not user resistance." },
    { title: "Do you handle automation and reporting as part of customisation?", desc: "Yes. Automation and reporting are core components of our CRM customisation work." },
    { title: "How long does CRM customisation take?", desc: "Typically 2-6 weeks depending on complexity." },
  ],
  crm_integration: [
    { title: "Can you integrate our CRM with custom or legacy systems?", desc: "Yes. We regularly integrate CRMs with proprietary and legacy platforms." },
    { title: "Will integrations slow down our CRM?", desc: "No. We design integrations with performance and reliability in mind." },
    { title: "Can integrations support automation and reporting?", desc: "Yes. Integration is the foundation for accurate automation and reporting." },
    { title: "Do you use middleware tools or direct APIs?", desc: "We choose the method based on stability, scale, and security requirements." },
    { title: "How long does CRM integration take?", desc: "Typically 2-6 weeks depending on system complexity." },
  ],
  crm_automation_ai: [
    { title: "Will automation replace our sales team?", desc: "No. It removes admin so they can focus on selling." },
    { title: "Can AI improve lead quality?", desc: "Yes. AI scoring highlights leads with the highest likelihood to convert." },
    { title: "Is automation risky if configured poorly?", desc: "Yes. That is why we design safeguards and validation rules." },
    { title: "Can automation adapt as we grow?", desc: "Yes. We build modular workflows that evolve with scale." },
    { title: "How long does CRM automation take?", desc: "Typically 3-6 weeks depending on scope and complexity." },
  ],
  seo_services: [
    { title: "How long does SEO take to show results?", desc: "Early improvements usually appear in 2-3 months. Strong momentum builds over 6-12 months depending on competition." },
    { title: "Do you guarantee rankings?", desc: "No serious SEO partner should. We guarantee disciplined execution and transparent results." },
    { title: "Is SEO still worth it with paid ads and AI search?", desc: "Yes. SEO compounds, reduces acquisition costs, and captures intent that ads cannot sustainably replace." },
    { title: "Do you work with existing content and sites?", desc: "Yes. Most engagements involve optimisation, restructuring, and improvement rather than rebuilds." },
    { title: "How do you report progress?", desc: "Clear dashboards covering rankings, traffic quality, conversions, and impact." },
  ],
  technical_seo: [
    { title: "How is technical SEO different from on-page SEO?", desc: "Technical SEO focuses on site infrastructure, crawlability, performance, and indexation. On-page SEO focuses on content and relevance. Both are essential, but technical SEO comes first." },
    { title: "How often should technical SEO be done?", desc: "A full audit is recommended annually or after major site changes. Monitoring and maintenance should be ongoing." },
    { title: "Can technical SEO improve rankings without new content?", desc: "Yes. Fixing crawl, speed, and indexation issues often leads to immediate ranking and traffic gains." },
    { title: "Do you work with development teams?", desc: "Yes. We collaborate directly with internal or external developers and provide implementation-ready guidance." },
    { title: "Will technical SEO affect conversions?", desc: "Absolutely. Faster sites and cleaner UX improve engagement, trust, and conversion rates." },
  ],
  local_seo: [
    { title: "How long does local SEO take to work?", desc: "Initial improvements are often seen within 4-8 weeks. Competitive markets take longer but compound over time." },
    { title: "Is Google Business Profile enough on its own?", desc: "No. GBP is critical, but it must be supported by strong website, citation, and authority signals." },
    { title: "Can you rank multiple locations?", desc: "Yes. We build structured multi-location frameworks without duplicate content risks." },
    { title: "Do reviews really affect rankings?", desc: "Yes. Review velocity, sentiment, and engagement all influence local visibility and conversions." },
    { title: "Is local SEO ongoing?", desc: "Yes. Competitors, reviews, and Google updates require continuous optimisation." },
  ],
  seo_audit: [
    { title: "How long does an SEO audit take?", desc: "Typically 2-3 weeks depending on site size and complexity." },
    { title: "Do you use automated tools only?", desc: "No. Tools support analysis, but insights come from experience and manual review." },
    { title: "Will this audit improve rankings on its own?", desc: "The audit identifies what to fix. Rankings improve when the recommendations are implemented." },
    { title: "Can you implement the fixes after?", desc: "Yes. Many clients retain us for ongoing SEO after the audit." },
    { title: "Is this suitable for large websites?", desc: "Yes. We regularly audit large, complex, and multi-location sites." },
  ],
  on_page_seo: [
    { title: "How long does on-page SEO take to show results?", desc: "Initial improvements often appear within 4-6 weeks, depending on competition and crawl frequency." },
    { title: "Is on-page SEO a one-time task?", desc: "Core optimisation is foundational, but pages should be reviewed periodically as intent and competition evolve." },
    { title: "Do you rewrite content completely?", desc: "Only when necessary. We optimise existing content first before recommending full rewrites." },
    { title: "Can you work with large sites?", desc: "Yes. We regularly optimise sites with hundreds or thousands of pages." },
    { title: "Does on-page SEO affect conversions?", desc: "Yes. Clear structure, intent alignment, and internal flow directly impact user behaviour." },
  ],
  off_page_seo: [
    { title: "How long does off-page SEO take to show results?", desc: "Typically 3-6 months, depending on competition and current authority levels." },
    { title: "Do you guarantee rankings?", desc: "No serious SEO provider guarantees rankings. We guarantee structured, measurable authority growth." },
    { title: "How many links do you build per month?", desc: "It depends on your industry and strategy. Quality always outweighs quantity." },
    { title: "Are backlinks safe?", desc: "Yes. We follow white-hat practices aligned with Google guidelines." },
    { title: "Can you fix past spammy links?", desc: "Yes. We provide backlink audits and disavow support." },
  ],
  e_commerce_seo: [
    { title: "How long does e-commerce SEO take to show results?", desc: "Initial gains often appear within 6-8 weeks. Strong category growth typically compounds over 3-6 months." },
    { title: "Do you optimise Shopify and WooCommerce stores?", desc: "Yes. We work across Shopify, WooCommerce, Magento, and custom platforms." },
    { title: "Can you handle large inventories?", desc: "Yes. We specialise in SEO for stores with hundreds or thousands of SKUs." },
    { title: "Do you write product descriptions?", desc: "We optimise and structure them first. Full rewrites are recommended only where necessary." },
    { title: "Does e-commerce SEO improve conversions?", desc: "Yes. Intent alignment and structure directly impact buying behaviour." },
  ],
  link_building: [
    { title: "Is link building still important for SEO?", desc: "Yes. High-quality backlinks remain one of the strongest ranking signals." },
    { title: "How many links do you build per month?", desc: "We focus on quality over quantity. Volumes depend on competition, industry, and goals." },
    { title: "Do you guarantee links?", desc: "We guarantee effort, quality standards, and transparency, not artificial numbers." },
    { title: "Can you clean up bad backlinks?", desc: "Yes. We provide backlink audits and disavow guidance where necessary." },
    { title: "Is this safe for long-term SEO?", desc: "Yes. Our methods align with Google's quality guidelines." },
  ],
  seo_migration: [
    { title: "Will I lose traffic during a migration?", desc: "If done correctly, traffic impact is minimal and temporary." },
    { title: "When should SEO be involved in a migration?", desc: "Before design or development begins. Late SEO causes losses." },
    { title: "How long does recovery take?", desc: "Usually 2-6 weeks if executed properly. Longer if errors occur." },
    { title: "Do you handle redirects?", desc: "Yes. Redirect mapping is a core part of our service." },
    { title: "Can you fix a bad migration?", desc: "Yes. We regularly recover sites after failed migrations." },
  ],
  social_media_marketing: [
    { title: "Which platforms should we use?", desc: "Only the platforms your audience actually uses. We define this in strategy." },
    { title: "Do you create content or only manage accounts?", desc: "We do both, depending on the engagement model." },
    { title: "Is paid social mandatory?", desc: "No. Paid is optional and used strategically." },
    { title: "How long before results show?", desc: "Visibility improves within weeks. Meaningful traction builds over months." },
    { title: "Do you support founder-led content?", desc: "Yes. Especially effective for B2B and service brands." },
  ],
  social_media_management: [
    { title: "Do you create content as well?", desc: "Yes. Depending on the engagement model, we can include content creation along with management." },
    { title: "How often do you post?", desc: "Cadence is defined based on platform, audience, and goals. We agree on this upfront." },
    { title: "Can we approve content before posting?", desc: "Yes. Approval workflows and feedback loops can be built into the process." },
    { title: "Do you respond to comments and messages?", desc: "We handle basic engagement and can escalate sales or support conversations as needed." },
    { title: "Is paid advertising included?", desc: "No. Paid social is a separate service that can be added if required." },
  ],
};

const faqKeyOverrides: Record<string, string> = {
  seo: "seo_services",
  "ecommerce-development": "ecommerce_website_development",
  "custom-web-development": "custom_website_development",
  "ai-chatbot-development": "ai_chatbots",
  "workflow-automation": "automation_workflows",
  "generative-ai-development": "generative_ai",
  "agentic-ai-development": "agentic_ai",
  "ai-agent-development": "ai_agents",
  "design-systems": "design_system",
  "erp-development": "erp",
  "ecommerce-seo": "e_commerce_seo",
};

export function resolveFaqKey(pageKey: string): string {
  const normalized = pageKey.toLowerCase().replace(/\//g, "").trim();
  if (faqKeyOverrides[normalized]) return faqKeyOverrides[normalized];
  const snake = normalized.replace(/-/g, "_");
  if (faqsByKey[snake]) return snake;
  if (faqsByKey[normalized]) return normalized;
  return "home";
}

export function getFaqItems(pageKey: string): FaqItem[] {
  const key = resolveFaqKey(pageKey);
  return faqsByKey[key] ?? faqsByKey.home;
}
