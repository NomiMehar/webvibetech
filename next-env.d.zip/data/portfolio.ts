export type PortfolioItem = {
  id: string;
  title: string;
  category: string;
  metric: string;
  accent: string;
};

export const portfolioItems: PortfolioItem[] = [
  {
    id: "1",
    title: "Commerce Mesh",
    category: "E-commerce platform",
    metric: "+38% conversion",
    accent: "Performance-led storefront with edge-cached product listing pages and a warm, trustworthy checkout UI.",
  },
  {
    id: "2",
    title: "Atlas Field",
    category: "Mobile + Sync",
    metric: "99.2% uptime",
    accent: "Offline-first operations app for distributed field teams, syncing reliably across low-connectivity environments.",
  },
  {
    id: "3",
    title: "Northstar CRM",
    category: "RevOps",
    metric: "4× faster handoffs",
    accent: "Custom CRM with objects and pipelines mirroring the client's actual sales motion — not a generic template.",
  },
  {
    id: "4",
    title: "Helix AI Desk",
    category: "AI Support",
    metric: "−52% tier-0 load",
    accent: "Grounded AI support system with human escalation paths and policy guardrails, reducing first-line ticket volume.",
  },
  {
    id: "5",
    title: "Lumen CMS",
    category: "Marketing site",
    metric: "LCP 0.9s",
    accent: "Headless CMS stack with editor guardrails and sub-second core web vitals across all target markets.",
  },
];
