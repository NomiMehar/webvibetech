export type Testimonial = {
  quote: string;
  name: string;
  role: string;
  company: string;
  rating: number;
};

export const testimonials: Testimonial[] = [
  {
    quote:
      "They shipped like an in-house team — clear rituals, ruthless prioritization, and interfaces that our executives actually complimented during the board review.",
    name: "Anonymized",
    role: "VP Product",
    company: "Series B SaaS Platform",
    rating: 5,
  },
  {
    quote:
      "The discovery phase alone saved us three months of rework. They asked the questions our previous agency never thought to ask.",
    name: "Anonymized",
    role: "CTO",
    company: "Healthcare Technology Company",
    rating: 5,
  },
  {
    quote:
      "Our CRM finally reflects how our sales team actually works. The adoption rate after launch was the highest we'd ever seen on an internal tool rollout.",
    name: "Anonymized",
    role: "Head of Revenue Operations",
    company: "B2B SaaS",
    rating: 5,
  },
  {
    quote:
      "Webvibe Tech kept every stakeholder informed without drowning them in Slack messages. The weekly updates were the clearest project communication I've experienced.",
    name: "Anonymized",
    role: "Digital Transformation Lead",
    company: "Logistics Group",
    rating: 5,
  },
  {
    quote:
      "The AI support system they built went live with zero major incidents. Six months later, it's still the most reliable thing in our stack.",
    name: "Anonymized",
    role: "Engineering Manager",
    company: "E-commerce Enterprise",
    rating: 5,
  },
];
