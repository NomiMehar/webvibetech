export type ServicesShowcaseSubService = {
  label: string;
  href: string;
};

export type ServicesShowcaseMainService = {
  slug: string; // matches SERVICE_GROUPS[groupId]
  title: string;
  href: string;
  description: string;
  image: string;
  items: string[];
  subServices: ServicesShowcaseSubService[];
};

export type ServicesShowcaseContent = {
  heading: string;
  subtitle: string;
  services: ServicesShowcaseMainService[];
};

/**
 * Content for the homepage "ServicesShowcase" section.
 * Hrefs are aligned to canonical `/services/[slug]/` routes.
 */
export const servicesShowcaseContent: ServicesShowcaseContent = {
  heading: "Explore Our Core Services",
  subtitle:
    "From software and mobile to AI, automation, SEO, and CRM systems, Webvibe Tech delivers the engineering foundations your business needs to scale.",
  services: [
    {
      slug: "ai-automation",
      title: "AI & Automation",
      href: "/services/ai-automation/",
      description:
        "Guardrailed AI systems, intelligent agents, and workflow automation that reduce manual overhead and embed machine intelligence into daily operations.",
      image: "/assets/images/services/services-showcase.png",
      items: [
        "AI chatbots, LLM integrations, and agentic workflows",
        "Evals, tracing, and human-in-the-loop policy gates",
        "Automation that reduces operational cost, not just task count",
      ],
      subServices: [
        { label: "AI Chatbot Development", href: "/services/ai-chatbot-development/" },
        { label: "LLM Development", href: "/services/llm-development/" },
        { label: "Workflow Automation", href: "/services/workflow-automation/" },
        { label: "Generative AI Development", href: "/services/generative-ai-development/" },
        { label: "Agentic AI Development", href: "/services/agentic-ai-development/" },
        { label: "AI Agent Development", href: "/services/ai-agent-development/" },
      ],
    },
    {
      slug: "mobile-app-development",
      title: "Mobile App Development",
      href: "/services/mobile-app-development/",
      description:
        "Native-quality iOS and Android apps with a predictable release cadence — from wireframe to App Store.",
      image: "/assets/images/services/services-showcase.png",
      items: [
        "iOS, Android, and cross-platform Flutter apps",
        "Offline-first architecture for field and enterprise use cases",
        "App UX design, QA, and post-launch maintenance",
      ],
      subServices: [
        { label: "iOS App Development", href: "/services/ios-app-development/" },
        { label: "Android App Development", href: "/services/android-app-development/" },
        { label: "Flutter App Development", href: "/services/flutter-app-development/" },
        { label: "App UI/UX Design", href: "/services/app-ui-ux-design/" },
        { label: "App Maintenance", href: "/services/app-maintenance/" },
      ],
    },
    {
      slug: "software-development",
      title: "Software Development",
      href: "/services/software-development/",
      description:
        "SaaS platforms, internal tools, and APIs engineered to scale — with observability and documentation built in from day one.",
      image: "/assets/images/services/services-showcase.png",
      items: [
        "Custom SaaS and web application development",
        "MVP scoping and rapid validation builds",
        "API design, versioning, and third-party integrations",
      ],
      subServices: [
        { label: "Custom Software Development", href: "/services/custom-software-development/" },
        { label: "Web App Development", href: "/services/web-app-development/" },
        { label: "SaaS Development", href: "/services/saas-development/" },
        { label: "MVP Development", href: "/services/mvp-development/" },
        { label: "API Development", href: "/services/api-development/" },
      ],
    },
    {
      slug: "website-development",
      title: "Website Development",
      href: "/services/website-development/",
      description:
        "Fast, SEO-ready websites designed for performance, scalability, and conversion — not just launch-day aesthetics.",
      image: "/assets/images/services/services-showcase.png",
      items: [
        "High-performance marketing sites and CMS builds",
        "E-commerce storefronts with seamless payment integration",
        "SEO-first architecture, conversion-led UX",
      ],
      subServices: [
        { label: "WordPress Development", href: "/services/wordpress-development/" },
        { label: "Shopify Development", href: "/services/shopify-development/" },
        { label: "E-Commerce Website Development", href: "/services/ecommerce-development/" },
        { label: "Landing Page Development", href: "/services/landing-page-development/" },
        { label: "Website Maintenance", href: "/services/website-maintenance/" },
        { label: "Custom Website Development", href: "/services/custom-web-development/" },
        { label: "Webflow Development", href: "/services/webflow-development/" },
      ],
    },
    {
      slug: "ui-ux-design",
      title: "UI & UX Design",
      href: "/services/ui-ux-design/",
      description:
        "Research-led product design that clarifies user intent and converts it into interfaces engineers can build — precisely and efficiently.",
      image: "/assets/images/services/services-showcase.png",
      items: [
        "UX research, audits, and information architecture",
        "Token-driven design systems with accessibility as a constraint",
        "High-fidelity prototypes that eliminate engineering ambiguity",
      ],
      subServices: [
        { label: "UX Research", href: "/services/ux-research/" },
        { label: "UI Design", href: "/services/ui-design/" },
        { label: "UX Audit", href: "/services/ux-audit/" },
        { label: "Wireframing & Prototyping", href: "/services/wireframing-prototyping/" },
        { label: "Design Systems", href: "/services/design-systems/" },
        { label: "Product Design", href: "/services/product-design/" },
      ],
    },
    {
      slug: "seo",
      title: "SEO",
      href: "/services/seo/",
      description:
        "Technical SEO, content strategy, and digital marketing programs that compound — built on data, not guesswork, and measured in organic growth.",
      image: "/assets/images/services/services-showcase.png",
      items: [
        "Technical SEO audits, on-page and off-page optimization",
        "Local SEO, e-commerce SEO, and migration-safe restructuring",
        "Social media marketing and management programs",
      ],
      subServices: [
        { label: "Technical SEO", href: "/services/technical-seo/" },
        { label: "Local SEO", href: "/services/local-seo/" },
        { label: "SEO Audit", href: "/services/seo-audit/" },
        { label: "On-page SEO", href: "/services/on-page-seo/" },
        { label: "Off-page SEO", href: "/services/off-page-seo/" },
        { label: "E-commerce SEO", href: "/services/ecommerce-seo/" },
        { label: "Link Building", href: "/services/link-building/" },
        { label: "SEO Migration", href: "/services/seo-migration/" },
        { label: "Social Media Marketing", href: "/services/social-media-marketing/" },
        { label: "Social Media Management", href: "/services/social-media-management/" },
      ],
    },
    {
      slug: "crm-development",
      title: "CRM Development",
      href: "/services/crm-development/",
      description:
        "CRM and ERP implementations that mirror how your revenue team actually works — with automation and AI layered in where they earn their place.",
      image: "/assets/images/services/services-showcase.png",
      items: [
        "Custom CRM builds and platform implementations",
        "ERP integration and cross-system data pipelines",
        "AI-assisted CRM automation and lead scoring",
      ],
      subServices: [
        { label: "CRM Implementation", href: "/services/crm-implementation/" },
        { label: "ERP Development", href: "/services/erp-development/" },
        { label: "CRM Customization", href: "/services/crm-customization/" },
        { label: "CRM Integration", href: "/services/crm-integration/" },
        { label: "CRM Automation & AI", href: "/services/crm-automation-ai/" },
      ],
    },
  ],
};

