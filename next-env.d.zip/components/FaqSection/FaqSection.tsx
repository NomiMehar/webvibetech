 "use client";

import { useState } from "react";
import type { FaqItem } from "@/data/faqs";
import styles from "./FaqSection.module.scss";

type Props = {
  items: FaqItem[];
  title?: string;
  kicker?: string;
};

export function FaqSection({ items, title = "Straight answers to common questions.", kicker = "Frequently Asked Questions" }: Props) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  if (!items.length) return null;

  return (
    <section className={styles.section}>
      <div className={styles.inner}>
        <p className={styles.kicker}>{kicker}</p>
        <h2 className={styles.title}>{title}</h2>
        <div className={styles.list}>
          {items.map((item, index) => {
            const isOpen = openIndex === index;
            return (
              <article key={item.title} className={styles.item} data-open={isOpen}>
                <button
                  type="button"
                  className={styles.question}
                  onClick={() => setOpenIndex((prev) => (prev === index ? null : index))}
                  aria-expanded={isOpen}
                >
                <span>{item.title}</span>
                <span className={styles.icon} aria-hidden>
                  <span className={styles.iconH} />
                  <span className={styles.iconV} />
                </span>
                </button>
                <div className={styles.answerWrap}>
                  <p className={styles.answer}>{item.desc}</p>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
