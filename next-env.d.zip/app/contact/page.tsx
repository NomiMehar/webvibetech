import type { Metadata } from "next";
import { ContactStrip } from "@/components/ContactStrip/ContactStrip";
import { FaqSection } from "@/components/FaqSection/FaqSection";
import { getFaqItems } from "@/data/faqs";
import styles from "./contact.module.scss";

export const metadata: Metadata = {
  title: "Start a Project | Webvibe Tech",
  description: "Start a Project | Webvibe Tech",
};

export default function ContactPage() {
  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.mesh} aria-hidden />
        <div className={`container ${styles.heroInner}`}>
          <p className={styles.kicker}>Project desk</p>
          <h1 className={styles.title}>Tell us what you&apos;re building next.</h1>
          <p className={styles.lede}>
            Share scope, timelines, or open questions — we reply with a thoughtful next step, not a
            generic auto-response. Reach us directly at{" "}
            <a href="mailto:info@webvibetech.com" className={styles.mail}>
              info@webvibetech.com
            </a>
            .
          </p>
        </div>
      </section>
      <ContactStrip />
      <FaqSection items={getFaqItems("home")} />
    </div>
  );
}
