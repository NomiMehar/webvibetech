import type { Metadata } from "next";
import { Inter, Poppins } from "next/font/google";
import { Header } from "@/components/Header/Header";
import { Footer } from "@/components/Footer/Footer";
import { ContactStripGate } from "@/components/ContactStrip/ContactStripGate";
import "@/styles/main.scss";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const poppins = Poppins({
  weight: ["400", "500", "600", "700"],
  subsets: ["latin"],
  variable: "--font-poppins",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://webvibetech.com"),
  title: {
    default: "Webvibe Tech | Software, AI & Digital Product Engineering",
    template: "%s | Webvibe Tech",
  },
  description: "Webvibe Tech | Software, AI & Digital Product Engineering",
  openGraph: {
    title: "Webvibe Tech | Software, AI & Digital Product Engineering",
    description: "Webvibe Tech | Software, AI & Digital Product Engineering",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${poppins.variable}`}>
      <body>
        <div className="grain" aria-hidden />
        <Header />
        <main>{children}</main>
        <ContactStripGate />
        <Footer />
      </body>
    </html>
  );
}
