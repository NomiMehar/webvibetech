import type { Metadata } from "next";
import Link from "next/link";
import { Button } from "@/components/Button/Button";
import { FaqSection } from "@/components/FaqSection/FaqSection";
import { getFaqItems } from "@/data/faqs";
import styles from "./about.module.scss";

export const metadata: Metadata = {
  title: "About Webvibe Tech | Senior-Led Studio for Digital Product Teams",
  description:
    "About Webvibe Tech | Senior-Led Studio for Digital Product Teams",
};

export default function AboutPage() {
  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.mesh} aria-hidden />
        <div className={`container ${styles.heroInner}`}>
          <p className={styles.kicker}>About Webvibe Tech</p>
          <h1 className={styles.title}>Built for teams who outgrow generic vendors.</h1>
          <p className={styles.lede}>
            We&apos;re a compact studio of strategists, engineers, and designers who measure success in
            shipped outcomes — not billed hours or slide decks. Every engagement is senior-led,
            transparent, and scoped before a single line of code is written.
          </p>
        </div>
      </section>
      <section className={styles.body}>
        <div className={`container ${styles.grid}`}>
          <div>
            <h2 className={styles.h2}>How we work</h2>
            <p className={styles.p}>
              Engagements start with a crisp problem frame: what must be true in 90 days, what
              constraints are immovable, and what success looks like in concrete numbers. From there
              we run overlapping discovery and delivery — so research informs the next build slice,
              not a document nobody reads.
            </p>
            <p className={styles.p}>
              You&apos;ll work directly with leads who still prototype, review pull requests, and run
              design critiques. No account-management layers. No bait-and-switch bench staffed after
              the proposal is signed. Just senior people who treat your roadmap as seriously as you
              do.
            </p>
          </div>
          <aside className={styles.aside}>
            <h3 className={styles.h3}>Principles</h3>
            <ul className={styles.list}>
              <li>Transparency beats theatre — progress is always legible, never behind a status meeting.</li>
              <li>Systems beat heroics — we build for maintainability, not individual brilliance.</li>
              <li>Craft is a commercial advantage — polish and precision reduce downstream rework.</li>
            </ul>
            <Button href="/contact" variant="primary">
              Start a conversation
            </Button>
            <Link href="/services" className={styles.link}>
              Browse services →
            </Link>
          </aside>
        </div>
      </section>
      <FaqSection items={getFaqItems("home")} />
    </div>
  );
}
