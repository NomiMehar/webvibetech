"use client";

import styles from "./TrustSection.module.scss";


const logos = ["SaaS Platforms", "E-commerce", "Startups & MVPs", "AI Products", "Enterprise Systems", "CRM & ERP Solutions"];

export function TrustSection() {
  return (
    <section className={styles.root} id="trust">
      <div className={styles.inner}>
        <div>
          <p className={styles.kicker}>Trusted by Startups, Enterprises & Growing Businesses</p>
          <h2 className={styles.title}>Delivery quality you can verify, not just trust.</h2>
          <p className={styles.body}>
          Trusted for custom software development, AI automation, and enterprise-grade solutions, we help teams launch faster, scale efficiently, and deliver measurable impact.
          </p>
          <div className={styles.logos} aria-label="Client sectors">
              {logos.map((name) => (
                <span key={`a-${name}`} className={styles.logoPill}>
                  {name}
                </span>
              ))}
          </div>
        </div>

      </div>
    </section>
  );
}
