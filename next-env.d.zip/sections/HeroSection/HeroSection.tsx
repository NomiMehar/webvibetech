"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Button } from "@/components/Button/Button";
import heroContent from "@/data/heroSectionContent.json";
import styles from "./HeroSection.module.scss";

const floatTransition = { duration: 4.5, repeat: Infinity, ease: "easeInOut" as const };
const cardClasses = [styles.c1, styles.c2, styles.c3];
const cardFloatY = [-10, 12, -8];
const cardDelay = [0, 0.12, 0.22];
const cardFloatDelay = [0, 0.4, 0.8];

export function HeroSection() {
  const reduce = useReducedMotion();

  return (
    <section className={styles.root} aria-label="Introduction">
      <div className={styles.bgMesh} aria-hidden />
      <div className={`${styles.blob} ${styles.a}`} aria-hidden />
      <div className={`${styles.blob} ${styles.b}`} aria-hidden />
      <div className="container">
      <div className={styles.inner}>
      <div className={styles.copy}>
          <p className={styles.eyebrow}>
            <span className={styles.dot} aria-hidden />
            {heroContent.eyebrow}
          </p>
          <h1 className={styles.headline}>
            {heroContent.headlinePrefix}{" "}
            <span className={styles.gradientWord}>{heroContent.headlineGradientWord}</span>{" "}
            {heroContent.headlineSuffix}
          </h1>
          <h2 className={styles.headline_two}>
            {heroContent.subheading}
          </h2>
          <p className={styles.lede}>
            {heroContent.description}
          </p>
          <div className={styles.ctas}>
            <Button href="/contact" variant="primary" size="lg">
              {heroContent.ctaPrimary}
            </Button>
            <Button href="/services" variant="secondary" size="lg">
              {heroContent.ctaSecondary}
            </Button>
          </div>
          <p className={styles.note}>{heroContent.trustLine}</p>
        </div>
        <div className={styles.visual}>
          <div className={styles.spark} aria-hidden />
          <div className={styles.stack}>
            {heroContent.cards.map((card, i) => (
              <motion.div
                key={card.title}
                className={`${styles.card} ${cardClasses[i] ?? ""}`}
                initial={reduce ? false : { opacity: 0, y: 24 + i * 4 }}
                animate={reduce ? undefined : { opacity: 1, y: [0, cardFloatY[i] ?? 0, 0] }}
                transition={
                  reduce
                    ? undefined
                    : {
                        opacity: { delay: cardDelay[i] ?? 0, duration: 0.7, ease: [0.16, 1, 0.3, 1] },
                        y: { ...floatTransition, delay: cardFloatDelay[i] ?? 0 },
                      }
                }
              >
                <div className={styles.cardKicker}>{card.kicker}</div>
                <div className={styles.cardTitle}>{card.title}</div>
                <p className={styles.cardBody}>{card.body}</p>
                <div className={styles.pillRow}>
                  {card.tags.map((tag) => (
                    <span key={tag} className={styles.pill}>
                      {tag}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      </div>
    </section>
  );
}
