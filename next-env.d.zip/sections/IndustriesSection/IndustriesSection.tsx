"use client";

import { motion, useReducedMotion } from "framer-motion";
import styles from "./IndustriesSection.module.scss";

const industries = [
  {
    name: "Fintech & Banking",
    detail:
      "Compliance-aware UX, payment flows, and secure APIs — built to satisfy auditors and delight end users simultaneously.",
  },
  {
    name: "Healthcare & Pharma",
    detail:
      "Patient journeys, HIPAA-aware data handling, and audited release processes that satisfy clinical and regulatory stakeholders.",
  },
  {
    name: "E-commerce & Retail",
    detail:
      "High-converting storefronts, ERP integrations, and customer lifecycle automation — from first click to repeat purchase.",
  },
  {
    name: "Logistics & Mobility",
    detail:
      "Dispatch systems, fleet management tools, and real-time coordination surfaces that reduce operational friction.",
  },
  {
    name: "Education & Media",
    detail:
      "Streaming platforms, subscription engines, and engagement loops designed to retain learners and readers.",
  },
  {
    name: "SaaS & AI Products",
    detail:
      "Onboarding flows, billing infrastructure, model ops tooling, and trust UX for emerging AI-native categories.",
  },
  {
    name: "Real Estate & PropTech",
    detail:
      "Property portals, 3D/2D tour integrations, and CRM-connected lead flows built for high-volume brokerage operations.",
  },
  {
    name: "Startups & Scaleups",
    detail:
      "MVPs that graduate gracefully to production — with documentation and architecture that survive your Series A.",
  },
  {
    name: "Media & Entertainment",
    detail:
      "Content hubs, streaming infrastructure, and audience engagement platforms serving diverse global audiences.",
  },
  {
    name: "Non-Profit & Government",
    detail:
      "Donation platforms, volunteer management portals, and impact tracking dashboards built for public accountability.",
  },
];

export function IndustriesSection() {
  const reduce = useReducedMotion();

  return (
    <section className={styles.root} id="industries" aria-labelledby="industries-heading">
      <div className={styles.inner}>
        <p className={styles.kicker}>Industries we serve</p>
        <h2 id="industries-heading" className={styles.title}>
          Context over templates — depth across sectors.
        </h2>
        <p className={styles.sub}>
          We've shipped in regulated, high-traffic, and zero-to-one environments. The approach is
          consistent: understand the domain deeply, then design systems that flex with operational
          reality.
        </p>
        <div className={styles.list}>
          {industries.map((item, i) => (
            <motion.div
              key={item.name}
              className={styles.row}
              initial={reduce ? false : { opacity: 0, x: -12 }}
              whileInView={reduce ? undefined : { opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-5%" }}
              transition={{ delay: i * 0.04, duration: 0.45 }}
            >
              <div className={styles.rowHead}>
                <span className={styles.mark} aria-hidden />
                <span className={styles.name}>{item.name}</span>
              </div>
              <p className={styles.detail}>{item.detail}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
